-- To-do List --

- Campo de "input" de texto e um botão para adicionar a tarefa à lista;
- Quando pressionado o botão, o texto deve aparecer na lista com um check-box ao lado;
- Quando o usuário selecionar o check-box, o item deve ficar com o texto riscado;

//-- Adicionais

- Ao selecionar o check-box, o item deve ser alocado para o final da lista;